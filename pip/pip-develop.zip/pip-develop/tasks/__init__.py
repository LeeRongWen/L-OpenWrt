import invoke

from . import generate

ns = invoke.Collection(generate)
